﻿using System;

class Program
{
    static void Main(string[] args)
    {
        
        TituloInicial();

        // Variable para controlar la salida del bucle
        bool salir = false;

        // Bucle principal que muestra el menú y la selección del usuario
        while (!salir)
        {
            // Mostramos el menú principal
            MenuPrincipal();

            // Obtenemos la opción válida del usuario
            int opcion = ObtenerOpcionValida();

            // Manejamos la opción seleccionada por el usuario
            switch (opcion)
            {
                case 1:
                    Console.Clear();
                    ProcesoPrincipal();
                    break;
                case 2:
                    Console.Clear();
                    ManualDeUsuario();
                    break;
                case 3:
                    Console.Clear();
                    Creditos();
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }
    }

    // Procedimiento para mostrar el título inicial del programa
    static void TituloInicial()
    {
        Console.WriteLine();
        Console.WriteLine("Nombre del proyecto: Tiempos de Produccion de la fabricacion de una empresa de bebidas");
        Console.WriteLine("Breve explicación: El programa es una aplicación de consola en C# " +
                          "que proporciona una estructura organizada para interactuar con el usuario a través de un menú principal.");
    }

    // Procedimiento para mostrar el menú principal
    static void MenuPrincipal()
    {
        Console.WriteLine();
        Console.WriteLine("Menú principal:");
        Console.WriteLine("1. Proceso principal (servicio)");
        Console.WriteLine("2. Manual de usuario");
        Console.WriteLine("3. Créditos");
        Console.WriteLine("4. Salir");
    }

    // Función para obtener una opción válida del usuario
    static int ObtenerOpcionValida()
    {
        int opcion;
        bool esValida = false;

        do
        {
            Console.Write("Seleccione una opción: ");
            if (int.TryParse(Console.ReadLine(), out opcion) && opcion >= 1 && opcion <= 5)
            {
                esValida = true;
            }
            else
            {
                Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
            }
        } while (!esValida);

        return opcion;
    }

    // Menu donde el usuario selecciona la bebida 
    static void ProcesoPrincipal()
    {
        Console.Clear();
        // Muestra un encabezado para el proceso principal
        Console.WriteLine("Proceso Principal");
        Console.WriteLine("Menú de bebidas para seleccionar:");
        Console.WriteLine("1. Gaseosas");
        Console.WriteLine("2. Agua pura");
        Console.WriteLine("3. Alcohólicas");
        Console.WriteLine("4. Energizantes");
        Console.WriteLine("5. Naturales");
        Console.WriteLine("6. Regresar al menú principal");

        // Se obtiene la opción del producto seleccionado por el usuario
        int opcionProducto = ObtenerOpcionProducto();

        if (opcionProducto == 6)
        {
            // Si se selecciona la opción 6, se regresa al menú principal
            return;
        }

        // Después de seleccionar un producto, muestra el menú de resultados
        MenuResultados(opcionProducto);
    }

    // Función para obtener una opción válida del usuario
    static int ObtenerOpcionProducto()
    {
        int opcion;
        bool esValida = false;

        do
        {
            // Solicita al usuario seleccionar una bebida
            Console.Write("Seleccione una bebida: ");
            if (int.TryParse(Console.ReadLine(), out opcion) && opcion >= 1 && opcion <= 6)
            {
                esValida = true;
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
            }
        } while (!esValida);

        return opcion;
    }

    // Menu de reultados despues de seleccionar la bebida 
    static void MenuResultados(int opcionProducto)
    {
        bool regresarAlMenuPrincipal = false;

        do
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("Menú de resultados:");
            Console.WriteLine("1. Mostrar resultados");
            Console.WriteLine("2. Regresar al menú anterior");
            Console.WriteLine("3. Regresar al menú principal");
            Console.WriteLine("4. Salir");
            Console.WriteLine();

            // Obtener la opción del usuario en el menú de resultados
            int opcionResultado = ObtenerOpcionValida();

            switch (opcionResultado)
            {
                case 1:
                    // Mostrar los resultados del tiempo de producción del producto seleccionado
                    MostrarResultados(opcionProducto);
                    Console.WriteLine();
                    Console.WriteLine("Presionar tecla -enter- para regresar al menú de resultados.");
                    Console.ReadKey();
                    break;
                case 2:
                    Console.Clear();
                    ProcesoPrincipal();
                    break;
                case 3:
                    Console.Clear();
                    regresarAlMenuPrincipal = true;
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("Gracias por utilizar el programa. Adióssssssssssssssssssssssssss.");
                    Environment.Exit(0);
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        } while (!regresarAlMenuPrincipal);
    }

    // Se muestran los resultados de la bebedia que se selecciono 
    static void MostrarResultados(int opcionProducto)
    {
        Console.WriteLine();
        switch (opcionProducto)
        {
            case 1: // Gaseosas
                MostrarSubmenuGaseosas();
                break;
            case 2: // Agua pura
                MostrarSubmenuAguaPura();
                break;
            case 3: // Alcohólicas
                MostrarSubmenuAlcoholicas();
                break;
            case 4: // Energizantes
                MostrarSubmenuEnergizantes();
                break;
            case 5: // Naturales
                MostrarSubmenuNaturales();
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // Submenús para cada tipo de bebida //

    // SubmenuGaseosas de las diferentes presentaciones 
    static void MostrarSubmenuGaseosas()
    {
        Console.WriteLine("Seleccione el tipo de presentación de bebida gaseosa:");
        Console.WriteLine();
        Console.WriteLine("1. Lata de 355 mL");
        Console.WriteLine("2. Botella de plástico de 600 mL");
        Console.WriteLine("3. Botella de plástico de 1.5 L");
        Console.WriteLine("4. Botella de plástico de 2.5 L");
        Console.WriteLine("5. Botella de plástico de 3 L");

        Console.WriteLine();

        int opcionPresentacion = ObtenerOpcionValida();
        Console.WriteLine();

        switch (opcionPresentacion)
        {
            case 1:
                Console.WriteLine("Tiempo de producción para Lata de 355 mL:");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 día");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 3 horas y 45 min");
                break;
            case 2:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 600 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 45 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 4 horas");
                break;
            case 3:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 1.5 L");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h con 20 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 55 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 15 min");
                break;
            case 4:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 2.5 L");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h con 25 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 1 h");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 25 min");
                break;
            case 5:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 3 L");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h con 30 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 1 h");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 30 min");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // SubmenuAguapura de las diferentes presentaciones
    static void MostrarSubmenuAguaPura()
    {
        Console.WriteLine("Seleccione el tipo de presentación de agua pura:");
        Console.WriteLine();
        Console.WriteLine("1. Botella de plástico de 750 mL");
        Console.WriteLine("2. Botella de plástico de 1000 mL");
        Console.WriteLine("3. Botella de plástico de 2 L");
        Console.WriteLine("4. Envase de plástico de 1 galon");
        Console.WriteLine("5. Botella de plástico de 8 L");

        int opcionPresentacion = ObtenerOpcionValida();
        Console.WriteLine();

        switch (opcionPresentacion)
        {
            case 1:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 750 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h con 10 min");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 50 min");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 2 horas y 45 min");
                break;
            case 2:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 1000 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h con 10 min");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 55 min");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 3 horas");
                break;
            case 3:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 2 L");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h con 10 min");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 55 min");
                Console.WriteLine(" - Etiquetado: 40 min");
                Console.WriteLine(" - Almacenamiento: ");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 3 horas y 25 min");
                break;
            case 4:
                Console.WriteLine("Tiempo de producción para Envase de plástico de 1 galon");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h con 10 min");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 1 h con 20 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 50 min");
                Console.WriteLine(" - Almacenamiento: ");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 4 horas");
                break;
            case 5:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 8 L");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 2 h");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 1 h con 35 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 55 min");
                Console.WriteLine(" - Almacenamiento: ");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 6 horas y 10 min");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // SubmenuAlcoholicas de las diferentes presentaciones
    static void MostrarSubmenuAlcoholicas()
    {
        Console.WriteLine("Seleccione el tipo de presentación de bebida alcoholica:");
        Console.WriteLine();
        Console.WriteLine("1. Lata de cerveza de 350 mL");
        Console.WriteLine("2. Lata de cerveza de 355 mL");
        Console.WriteLine("3. Lata de cerveza de 680 mL ");
        Console.WriteLine("4. Botella de vidrio de ron de 750 mL");
        Console.WriteLine("5. Botella de vidrio de ron de 1750 mL");

        int opcionPresentacion = ObtenerOpcionValida();
        Console.WriteLine();

        switch (opcionPresentacion)
        {
            case 1:
                Console.WriteLine("Tiempo de producción para Lata de cerveza de 350 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 2 h");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 50 min");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 35 mins");
                break;
            case 2:
                Console.WriteLine("Tiempo de producción para Lata de cerveza de 355 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 2 h");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 50 min");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 4 horas y 35 min");
                break;
            case 3:
                Console.WriteLine("Tiempo de producción para Lata de cerveza de 680 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 2 h con 15 min");
                Console.WriteLine(" - Revisión de envases: 45 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 15 min");
                break;
            case 4:
                Console.WriteLine("Tiempo de producción para Botella de vidrio de ron de 750 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 2 dias");
                Console.WriteLine(" - Purificación: 2 dias");
                Console.WriteLine(" - Revisión de envases: 45 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 5 días con 3 horas");
                break;
            case 5:
                Console.WriteLine("Tiempo de producción para Botella de vidrio de ron de 1750 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 2 dias");
                Console.WriteLine(" - Purificación: 2 dias");
                Console.WriteLine(" - Revisión de envases: 50 min");
                Console.WriteLine(" - Envasado: 1 h con 10 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 55 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 5 días con 3 horas y 55 min");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // SubmenuEnergizantes de las diferentes presentaciones
    static void MostrarSubmenuEnergizantes()
    {
        Console.WriteLine("Seleccione el tipo de presentación de bebida energizante:");
        Console.WriteLine();
        Console.WriteLine("1. Lata de 250 mL");
        Console.WriteLine("2. Lata de 473 mL");
        Console.WriteLine("3. Botella de plástico de 600 mL");

        int opcionPresentacion = ObtenerOpcionValida();
        Console.WriteLine();

        switch (opcionPresentacion)
        {
            case 1:
                Console.WriteLine("Tiempo de producción para Lata de 250 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 40 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 3 horas y 45 min");
                break;
            case 2:
                Console.WriteLine("Tiempo de producción para Lata de 473 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 45");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 35 min");
                Console.WriteLine(" - Etiquetado: 30 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 3 horas y 50 min");
                break;
            case 3:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 600 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 45");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 4 horas");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // SubmenuNaturales de las diferentes presentaciones
    static void MostrarSubmenuNaturales()
    {
        Console.WriteLine("Seleccione el tipo de presentación de bebida natural:");
        Console.WriteLine();
        Console.WriteLine("1. Botella de plástico de 500 mL");
        Console.WriteLine("2. Envase de cartón de 946 mL");
        Console.WriteLine("3. Botella de plástico de 1,500 mL");
        Console.WriteLine("4. Botella de plástico de 1,800 mL");
        Console.WriteLine("5. Envase de plástico de 3,400 mL");

        int opcionPresentacion = ObtenerOpcionValida();
        Console.WriteLine();

        switch (opcionPresentacion)
        {
            case 1:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 500 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 45 min");
                Console.WriteLine(" - Envasado: 1 h");
                Console.WriteLine(" - Tapado y sellado: 40 min");
                Console.WriteLine(" - Etiquetado: 35 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 dias con 4 horas");
                break;
            case 2:
                Console.WriteLine("Tiempo de producción para Envase de cartón de 946 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h 20 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 55 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 15 min");
                break;
            case 3:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 1,500 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h 25 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 55 min");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 20 min");
                break;
            case 4:
                Console.WriteLine("Tiempo de producción para Botella de plástico de 1,800 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h 30 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 1 h");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 30 min");
                break;
            case 5:
                Console.WriteLine("Tiempo de producción para Envase de plástico de 3,400 mL");
                Console.WriteLine();
                Console.WriteLine(" - Abastecimiento de agua: 1 dia");
                Console.WriteLine(" - Purificación: 1 h");
                Console.WriteLine(" - Revisión de envases: 1 h");
                Console.WriteLine(" - Envasado: 1 h 40 min");
                Console.WriteLine(" - Tapado y sellado: 1 h");
                Console.WriteLine(" - Etiquetado: 1 h");
                Console.WriteLine(" - Almacenamiento: 1 dia");
                Console.WriteLine();
                Console.WriteLine(" - Tiempo total de producción: 2 días con 5 horas y 40 min");
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    // Informacion de Manual de Usuario 
    static void ManualDeUsuario()
    {
        Console.WriteLine();
        Console.WriteLine("Manual de usuario: ");
        Console.WriteLine();
        Console.WriteLine("Lista y explicacion de todas las opciones que posee el programa:");
        Console.WriteLine();
        Console.WriteLine("Opcion 1: Proceso principal (servicio) ejecuta la funcion principal del programa.");
        Console.WriteLine("Opcion 2: Manual de usuario muestra instrucciones de uso del programa.");
        Console.WriteLine("Opcion 3: Creditos muestra informacion sobre el proyecto y sus autores.");
        Console.WriteLine("Opcion 4: Salir permite salir del programa.");
        Console.WriteLine();
        Console.WriteLine("Lista de los pasos a seguir para mostrar solucion de problematica:");
        Console.WriteLine();
        Console.WriteLine("Entradas: ");
        Console.WriteLine();
        Console.WriteLine(" - Seleccionar en el menu principal si se desea ingresar a los procesos, manual de usuario, créditos o salir del programa.");
        Console.WriteLine(" - Seleccionar el tipo de bebida de la que se quiere obtener el tiempo de sus procesos.");
        Console.WriteLine(" - Seleccionar en el menú resultados si se desean ver los resultados de los tiempos, si se quiere regresar al menú anterior, menú principal o si desea salir del programa.");
        Console.WriteLine(" - Seleccionar la presentación de la bebida en cantidad de volumen para ver los resultados de los tiempos.");
        Console.WriteLine();
        Console.WriteLine("Salidas: ");
        Console.WriteLine();
        Console.WriteLine(" - Si se selecciona menú principal, el programa mostrará los tipos de bebidas que tiene la empresa.");
        Console.WriteLine(" - Si se selecciona manual de usuario, el programa mostrará las reglas del programa.");
        Console.WriteLine(" - Si se selecciona créditos, el programa mostrará los datos de los integrantes y de la creación del programa.");
        Console.WriteLine(" - Si se desea salir, el programa cerrará el programa.");
        Console.WriteLine(" - Cuando se seleccione el tipo de bebida, el programa mostrará el menú resultado.");
        Console.WriteLine(" - Si se escoge el tipo de presentación en cantidad de volumen el programa\r\nmostrara los tiempos totales de la producción de las bebidas en abastecimiento del agua, purificación, revisión de envases, envasado, tapado y sellado, etiquetado y almacenamiento.");
        Console.WriteLine(" - Si se desea regresar al menú anterior o al principal, el programa regresará.");
        Console.WriteLine();
        Console.WriteLine("Explicacion detallada del proposito del programa:");
        Console.WriteLine();
        Console.WriteLine("El propósito del programa es determinar los tiempos en el abastecimiento de agua, purificación, revisión de envases, envasado, tapado y sellado, etiquetado y almacenamiento del " +
                          "agua pura, bebidas gaseosas, alcohólicas, energizantes y naturales para poder saber cuánto toman todos los procesos de la producción de una bebida y así reducir tiempos " +
                          "y costos dentro de la empresa.");
    }

    // Informacion de Creditos
    static void Creditos()
    {
        Console.WriteLine();
        Console.WriteLine("Creditos: ");
        Console.WriteLine();
        Console.WriteLine("Nombre del proyecto: Tiempos de Producción de la fabricación de una empresa de bebidas.");
        Console.WriteLine("Fecha de creación: Guatemala, Martes 29 de agosto de 2023");
        Console.WriteLine("Estimado de horas invertidas en creación del programa: 9 horas con 30 minutos");
        Console.WriteLine();
        Console.WriteLine("Informacion de integrantes:");
        Console.WriteLine();
        Console.WriteLine("Nombre y apellido de integrantes");
        Console.WriteLine();
        Console.WriteLine("Integrante 1: Jorge Alejandro Contreras Rivera");
        Console.WriteLine("Integrante 2: José Esteban Alvarez Aquino");
        Console.WriteLine();
        Console.WriteLine("Carné de integrantes");
        Console.WriteLine();
        Console.WriteLine("Integrante 1: 1128123");
        Console.WriteLine("Integrante 2: 1114723");
        Console.WriteLine();
        Console.WriteLine("Carrera de integrantes");
        Console.WriteLine();
        Console.WriteLine("Integrante 1: Ingeniería Industrial");
        Console.WriteLine("Integrante 2: Ingeniería Industrial");
    }
}