﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Jose Esteban Alvarez Aquino 1114723 ");
        Console.WriteLine("Ingrese una cantidad en quetzales (entre 0.00 y 999.99): ");
        double Quetzales = double.Parse(Console.ReadLine());

       
        if (Quetzales >= 0.00 && Quetzales <= 999.99)
        {
            int Centavos = (int)(Quetzales * 100);

            int billetes100 = Centavos / 10000;
            Centavos %= 10000;

            int billetes50 = Centavos / 5000;
            Centavos %= 5000;

            int billetes20 = Centavos / 2000;
            Centavos %= 2000;

            int billetes10 = Centavos / 1000;
            Centavos %= 1000;

            int billetes5 = Centavos / 500;
            Centavos %= 500;

            int monedas1 = Centavos / 100;
            Centavos %= 100;

            int monedas25 = Centavos / 25;
            Centavos %= 25;

            int monedas1centavo = Centavos;

            Console.WriteLine("Equivalencia en billetes y monedas de los quetzales previamente ingresados:");
            Console.WriteLine($"Billetes de 100 quetzales: {billetes100}");
            Console.WriteLine($"Billetes de 50 quetzales: {billetes50}");
            Console.WriteLine($"Billetes de 20 quetzales: {billetes20}");
            Console.WriteLine($"Billetes de 10 quetzales: {billetes10}");
            Console.WriteLine($"Billetes de 5 quetzales: {billetes5}");
            Console.WriteLine($"Monedas de 1 quetzal: {monedas1}");
            Console.WriteLine($"Monedas de 25 centavos: {monedas25}");
            Console.WriteLine($"Monedas de 1 centavo: {monedas1centavo}");
        }
        else
        {
            Console.WriteLine("La cantidad ingresada está fuera del rango permitido.");
            Console.ReadKey();
        }
    }
}

