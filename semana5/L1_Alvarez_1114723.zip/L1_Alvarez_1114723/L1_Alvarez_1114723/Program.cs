﻿class Program
{
static void Main(string[] args)
    {
        Console.WriteLine("INGRESE SU NOMBRE");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola mundo");
        Console.WriteLine("Soy " + Nombre);

        /*COMENTARIOS*/

        Console.Write("Hola mundo ");
        Console.Write("Soy " + Nombre);
        Console.ReadKey();
    }

}