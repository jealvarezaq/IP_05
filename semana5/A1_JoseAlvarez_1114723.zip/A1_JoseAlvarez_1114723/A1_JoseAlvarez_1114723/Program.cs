﻿using System;

class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, sCarrera, sCarne;

        //ingreso nombre
        Console.WriteLine("Ingrese nombre: ");
        sNombre = Console.ReadLine();
        //ingreso edad
        Console.WriteLine("Ingrese edad: ");
        sEdad = Console.ReadLine();
        //ingreso de carrera
        Console.WriteLine("Ingrese carrera: ");
        sCarrera = Console.ReadLine();
        //ingreso de carne 
        Console.WriteLine("Ingrese Carne: ");
        sCarne = Console.ReadLine();


        Console.WriteLine("mi segundo programa");
        Console.WriteLine("Nombre " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera : " + sCarrera);
        Console.WriteLine("Carne: " + sCarne);

        Console.Write("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera);
        Console.Write(", Mi numero de carne es; " + sCarne);

        Console.ReadKey();
    }





}