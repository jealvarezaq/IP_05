﻿using System;

class program

{

    static void Main(string[] args)

    {

        Console.WriteLine("Ejercicio 1");

        int a; 

       
        Console.WriteLine("Ingresar numero enterp");

        a = int.Parse(Console.ReadLine());

        if (a > 0)
        {
            Console.WriteLine("El numero es positivo");
        }
        else if (a < 0)
        {
            Console.WriteLine("El numero es negativo");
        }
        else 
         {
            Console.WriteLine("El numero es igual a 0");
        }

        Console.WriteLine("Ejercicio 2");

        Console.WriteLine("Ingrese el numero de dia: ");
        int dia = int.Parse(Console.ReadLine());

        switch (dia)
        {
            case 1:
                Console.WriteLine("Lunes");
                break;

            case 2:
                Console.WriteLine("martes");
                break;
            case 3:
                Console.WriteLine("miercoles");
                break;
            case 4:
                Console.WriteLine("jueves");
                break;
            case 5:
                Console.WriteLine("viernes");
                break;
            case 6:
                Console.WriteLine("sabado");
                break;
            case 7:
                Console.WriteLine("domingo");
                break;
            default:
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                break;


        }









        Console.ReadKey();

    }











}
