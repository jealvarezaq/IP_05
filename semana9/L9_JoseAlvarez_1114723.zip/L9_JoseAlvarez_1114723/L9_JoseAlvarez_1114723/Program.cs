﻿using System;

class Program
{
    static void Main()
    {
        double monto;

        while (true)
        {
            Console.WriteLine("Ingrese el monto total de la compra: ");
            if (double.TryParse(Console.ReadLine(), out monto))
                break;
            else
                Console.WriteLine("Debe ingresar únicamente números.");
        }

        double descuento = 0;
        string porcentaje = "";

        if (monto < 400)
        {
            porcentaje = "0%";
        }
        else if (monto >= 400)
        {
            if (monto < 1000)
            {
                descuento = 0.07; // 7% de descuento
                porcentaje = "7%";
            }
            else if (monto >= 1000)
            {
                if (monto < 5000)
                {
                    descuento = 0.10; // 10% de descuento
                    porcentaje = "10%";
                }
                else if (monto >= 5000)
                {
                    if (monto < 15000)
                    {
                        descuento = 0.15; // 15% de descuento
                        porcentaje = "15%";
                    }
                    else
                    {
                        descuento = 0.25; // 25% de descuento
                        porcentaje = "25%";
                    }
                }
            }
        }

        Console.WriteLine("¿Desea aplicar un código de descuento? (si/no): ");
        string respuesta = Console.ReadLine().ToLower();

        if (respuesta == "si")
        {
            descuento += 0.05; // 5% de descuento adicional
            porcentaje += " + 5%";
        }

        double montoDescuento = monto * descuento;
        double montoTotal = monto - montoDescuento;

        string DescuentoAdicional = respuesta == "si" ? "con código de descuento adicional" : "sin código de descuento adicional";

        Console.WriteLine($"Monto a pagar {DescuentoAdicional}: {montoTotal:C2}");
        Console.WriteLine($"Porcentaje de descuento aplicado: {porcentaje}");
    }
}


