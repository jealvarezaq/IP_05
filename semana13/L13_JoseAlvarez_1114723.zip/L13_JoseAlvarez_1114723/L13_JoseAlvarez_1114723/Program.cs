﻿using System;

class Program
{
    static void Main()
    {
      
        int[] numeros = new int[10];

       
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Ingrese el número {i + 1}: ");
            numeros[i] = Convert.ToInt32(Console.ReadLine());
        }

        
        Console.WriteLine($"Número más pequeño: {EncontrarNumeroMinimo(numeros)}");

       
        Console.WriteLine($"Número más grande: {EncontrarNumeroMaximo(numeros)}");

        Console.WriteLine($"Suma de todos los números: {CalcularSuma(numeros)}");

        
        Console.WriteLine("Números ordenados de 0 a la última posición:");
        MostrarArreglo(numeros);

        
        Console.WriteLine("Números ordenados de la última posición a 0:");
        MostrarArregloInverso(numeros);

        
        Console.WriteLine($"Promedio de los números: {CalcularPromedio(numeros)}");

       
        Console.WriteLine($"Suma de posiciones pares: {CalcularSumaPosicionesPares(numeros)}");
        Console.WriteLine($"Suma de posiciones impares: {CalcularSumaPosicionesImpares(numeros)}");
        Console.ReadKey();
    }

   
    static int EncontrarNumeroMinimo(int[] array)
    {
        int minimo = array[0];
        foreach (int numero in array)
        {
            if (numero < minimo)
            {
                minimo = numero;
            }
        }
        return minimo;
    }

   
    static int EncontrarNumeroMaximo(int[] array)
    {
        int maximo = array[0];
        foreach (int numero in array)
        {
            if (numero > maximo)
            {
                maximo = numero;
            }
        }
        return maximo;
    }

    
    static int CalcularSuma(int[] array)
    {
        int suma = 0;
        foreach (int numero in array)
        {
            suma += numero;
        }
        return suma;
    }

    
    static void MostrarArreglo(int[] array)
    {
        foreach (int numero in array)
        {
            Console.Write($"{numero} ");
        }
        Console.WriteLine();
    }

    
    static void MostrarArregloInverso(int[] array)
    {
        for (int i = array.Length - 1; i >= 0; i--)
        {
            Console.Write($"{array[i]} ");
        }
        Console.WriteLine();
    }

    
    static double CalcularPromedio(int[] array)
    {
        return (double)CalcularSuma(array) / array.Length;
    }

    
    static int CalcularSumaPosicionesPares(int[] array)
    {
        int suma = 0;
        for (int i = 0; i < array.Length; i += 2)
        {
            suma += array[i];
        }
        return suma;
    }

   
    static int CalcularSumaPosicionesImpares(int[] array)
    {
        int suma = 0;
        for (int i = 1; i < array.Length; i += 2)
        {
            suma += array[i];
        }
        return suma;
    }
}

