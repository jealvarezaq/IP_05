﻿// Integrantes: 
// Integrante 1: Jorge Alejandro Contreras Rivera - 1128123 - Ingenieria Industrial
// Integrante 2: José Esteban Alvarez Aquino - 1114723 - Ingenieria Industrial
using System;

class Program
{
    static void Main(string[] args)
    {
        TituloInicial();
        bool salir = false;
        while (!salir)
        {
            MenuPrincipal();
            int opcion = ObtenerOpcionValida();

            switch (opcion)
            {
                case 1:
                    ProcesoPrincipal();
                    break;
                case 2:
                    ManualDeUsuario();
                    break;
                case 3:
                    Creditos();
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opcion no valida. Por favor, seleccione una opcion valida.");
                    break;
                    
            }
        }
    }
    
    static void TituloInicial()
    {
        Console.WriteLine();
        Console.WriteLine("Nombre del proyecto: Tiempos de Produccion de la fabricacion de una empresa de bebidas");
        Console.WriteLine("Breve explicacion: El programa es una aplicacion de consola en C# " +
                          "que proporciona una estructura organizada para interactuar con el usuario a traves de un menu principal.");
    }
    static void MenuPrincipal()
    {
        Console.WriteLine();
        Console.WriteLine("Menú principal:");
        Console.WriteLine("1. Proceso principal (servicio)");
        Console.WriteLine("2. Manual de usuario");
        Console.WriteLine("3. Creditos");
        Console.WriteLine("4. Salir");
    }
    static int ObtenerOpcionValida()
    {
        int opcion;
        bool V = false;

        do
        {
            Console.Write("Seleccione una opcion: ");
            if (int.TryParse(Console.ReadLine(), out opcion) && opcion >= 1 && opcion <= 4)
            {
                V = true;
            }
            else
            {
                Console.WriteLine("Opcion no valida. Por favor, seleccione una opcion valida.");
            }
        } while (!V);

        return opcion;
    }
    static void ProcesoPrincipal()
    {
        Console.WriteLine();
        Console.WriteLine("Proceso principal: ");
    }
    static void ManualDeUsuario()
    {
        Console.WriteLine();
        Console.WriteLine("Manual de usuario: ");
        Console.WriteLine();
        Console.WriteLine("Lista y explicacion de todas las opciones que posee el programa:");
        Console.WriteLine("Opción 1: Proceso principal (servicio) ejecuta la funcion principal del programa.");
        Console.WriteLine("Opción 2: Manual de usuario muestra instrucciones de uso del programa.");
        Console.WriteLine("Opción 3: Creditos muestra informacion sobre el proyecto y sus autores.");
        Console.WriteLine("Opción 4: Salir permite salir del programa.");
        Console.WriteLine();
        Console.WriteLine("Lista de los pasos a seguir para mostrar solucion de problematica:");
        Console.WriteLine("Entradas: ");
        Console.WriteLine(" - Seleccionar en el menú principal si se desea ingresar a los procesos, manual de usuario, créditos o salir del programa. ");
        Console.WriteLine(" - Seleccionar el tipo de bebida de la que se quiere obtener el tiempo de sus procesos. ");
        Console.WriteLine(" - Seleccionar en el menú resultados si se desean ver los resultados de los tiempos, si se quiere regresar al menú anterior, menú principal o si desea salir del programa.");
        Console.WriteLine(" - Seleccionar la presentación de la bebida en cantidad de volumen para ver los resultados de los tiempos. ");
        Console.WriteLine();
        Console.WriteLine("Salidas: ");
        Console.WriteLine(" - Si se selecciona menú principal el programa mostrará los tipos de bebidas que tiene la empresa. ");
        Console.WriteLine(" - Si se selecciona manual de usuario el programa mostrará las reglas del programa. ");
        Console.WriteLine(" - Si se selecciona créditos el programa mostrará los datos de los integrantes y de la creación del programa. ");
        Console.WriteLine(" - Si se desea salir el programa cerrará el programa. ");
        Console.WriteLine(" - Cuando se seleccione el tipo de bebida el programa mostrara el menú resultado. ");
        Console.WriteLine(" - Si se escoge el tipo de presentación en cantidad de volumen el programa mostrara los tiempos totales de la producción de las bebidas. ");
        Console.WriteLine(" - Si se desea regresar al menú anterior o al principal el programa regresará. ");
        Console.WriteLine();
        Console.WriteLine("Explicacion detallada del proposito del programa:");
        Console.WriteLine("El proposito del programa es determinar los tiempos en el abastecimiento de agua, purificación, revisión de envases, envasado, tapado y sellado, etiquetado y almacenamiento del " + 
                          "agua pura, bebidas gaseosas, alcohólicas, energizantes y naturales para poder saber cuánto toman todos los procesos de la producción de una bebida y así reducir tiempos " + 
                          "y costos dentro de la empresa. ");
    }
    static void Creditos()
    {
        Console.WriteLine();
        Console.WriteLine("Creditos: ");
        Console.WriteLine("Nombre del proyecto: Tiempos de Produccion de la fabricacion de una empresa de bebidas.");
        Console.WriteLine("Fecha de creación: Guatemala, Martes 29 de agosto de 2023");
        Console.WriteLine("Estimado de horas invertidas en creación del programa: 3 horas");
        Console.WriteLine();
        Console.WriteLine("Información de integrantes:");
        Console.WriteLine();
        Console.WriteLine("Nombre y apellido de integrantes");
        Console.WriteLine("Integrante 1: Jorge Alejandro Contreras Rivera");
        Console.WriteLine("Integrante 2: José Esteban Alvarez Aquino");
        Console.WriteLine();
        Console.WriteLine("Carné de integrantes");
        Console.WriteLine("Integrante 1: 1128123");
        Console.WriteLine("Integrante 2: 1114723");
        Console.WriteLine();
        Console.WriteLine("Carrera de integrantes");
        Console.WriteLine("Integrante 1: Ingenieria Industrial");
        Console.WriteLine("Integrante 2: Ingenieria Industrial");
    }
}