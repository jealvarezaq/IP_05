﻿using System;

class program

{

    static void Main(string[] args)

    {

        Console.WriteLine("Ejercicio 1: Operaciones aritméticas");

        double numero1 = 0.0;

        double numero2 = 0.0;



        Console.WriteLine("Ingrese el primer numero");

        numero1 = double.Parse(Console.ReadLine());



        Console.WriteLine("Ingrese el segundo numero");

        numero2 = double.Parse(Console.ReadLine());



        double suma = 0.0;
        double resta = 0.0;
        double multiplicacion = 0.0;
        double division = 0.0;
        double div = 0.0;
        double mod = 0.0;


        suma = numero1 + numero2;
        resta = numero1 - numero2;
        multiplicacion = numero1*numero2;
        division = numero1/numero2;
        div = (int)numero1/ (int)numero2;
        mod = numero1 % numero2;

        Console.WriteLine(numero1 + " + " + numero2 + " = " + suma);
        Console.WriteLine(numero1 + " - " + numero2 + " = " + resta);
        Console.WriteLine(numero1 + " * " + numero2 + " = " + multiplicacion);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + division);
        Console.WriteLine(numero1 + " div " + numero2 + " = " + div);
        Console.WriteLine(numero1 + " mod " + numero2 + " = " + mod);

        Console.WriteLine("Ejercicio 2: Operaciones booleanas");

        bool mayorque = numero1>numero2;
        bool menorque = numero1<numero2;
        bool igualque = numero1 == numero2;

        Console.WriteLine(numero1 + " > " + numero2 + " = " + mayorque);
        Console.WriteLine(numero1 + " < " + numero2 + " = " + menorque);
        Console.WriteLine(numero1 + " = " + numero2 + " = " + igualque);

        Console.WriteLine("Ejercicio 3: jerarquia de operaciones");

        double a = 0.0;
        double b = 0.0;
        double c = 0.0;

        Console.WriteLine("Ingrese el primer numero para la variable a");

        a = double.Parse(Console.ReadLine());


        Console.WriteLine("Ingrese el segundo numero para la variable b");

        b = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese el tercer numero para la variable c");

        c = double.Parse(Console.ReadLine());

        double operacion1 = 0.0;
        double operacion2 = 0.0;
        double operacion3 = 0.0;
        double operacion4 = 0.0;

        operacion1 = (a*b)+c;
        operacion2 = a*(b+c);
        operacion3 = (a)/(b*c);
        operacion4 = (3*a+2*b)/(c*c);

        Console.WriteLine(" La operacion de la multiplicacion de " + a + " * " + b + " + " + c + " es " + operacion1);
        Console.WriteLine(" La operacion de la multiplicacion de  " + a + " por la suma de  " + b + " y " + c + " es " + operacion2);
        Console.WriteLine(" La operacion de " + a + " divido el producto de " + b + " * " + c + " es " + operacion3);
        Console.WriteLine(" La operacion de la suma de tres veces " + a + " + dos veces " + b + " divido " + c + " al cuadrado es " + operacion4);

        Console.WriteLine("Ejercicio 4: Calcular el valor de la expresion cuadratica");
        if (a==0)
        {
            Console.WriteLine("El valor de a no puede ser igual a 0");
            return;
        }

        double operacion5 = 0.0;

        operacion5 = b*b -(4*a*c);

        if (operacion5 >=0)
        {
            double x1 = 0.0;
            x1 = (-b + Math.Sqrt(operacion5)/(2*a));
            double x2 = 0.0;
            x2= (-b - Math.Sqrt(operacion5)/(2*a));

            Console.WriteLine("Las soluciones son x1 = " + x1 + " y x2 = " + x2);

        }
        else
        {
            Console.WriteLine("La parte que contiene raiz en la ecuacion cuadratica denominado deiscriminante es negativo y no tiene soluciones reales");
        }
        Console.ReadLine();

    }
}
