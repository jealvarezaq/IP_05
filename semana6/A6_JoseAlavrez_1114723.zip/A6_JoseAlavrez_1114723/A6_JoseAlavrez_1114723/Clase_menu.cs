﻿using System.Linq.Expressions;

class Clase_menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Programa de tiempos de produccion de filas de bebidas de una empresa");
        Console.WriteLine();
        Console.WriteLine("Seleccione opcion");
        Console.WriteLine();
        Console.WriteLine("Menu de bebidas");
        Console.WriteLine("1. naturales");
        Console.WriteLine("2. alcoholicas");
        Console.WriteLine("3. energizantes");
        Console.WriteLine("4. gaseosas");
        Console.WriteLine("5. agua pura");
        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("Selecciono opcion: " + opcion + "naturales");
                break;
            case "2":
                Console.WriteLine("Selecciono opcion: " + opcion + "alcoholicas");
                break;
            case "3":
                Console.WriteLine("Selecciono opcion: " + opcion + "energizantes");
                break;
            case "4":
                Console.WriteLine("Selecciono opcion: " + opcion + "gaseosas");
                break;
            case "5":
                Console.WriteLine("Selecciono opcion: " + opcion + "Agua pura");
                break;
            default:
                Console.WriteLine("Selecciono una opcion invalida");
                break;
        }
        Console.ReadKey();
    }
}